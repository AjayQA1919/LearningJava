package ex_06_Ternary_Operator;

public class Lab062_TO {
    public static void main(String[] args) {

        //  ? :
        int age = 27;
        String canIGoTOGoa =  age > 18 ? "Yes You can" : "You can't";
        System.out.println(canIGoTOGoa);



    }
}
