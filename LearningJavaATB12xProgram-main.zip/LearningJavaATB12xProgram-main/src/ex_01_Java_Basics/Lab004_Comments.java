package ex_01_Java_Basics;

public class Lab004_Comments {

    // This is comment, it will be ignored by the compiler
    //
}
