package ex_01_Java_Basics;

public class Lab013_Println_vs_Print {
    public static void main(String[] args) {

//        System.out.println("Hi"); // newline
//        System.out.println("Bye");

        System.out.print("Hi"); // newline
        System.out.print("Bye");




    }
}
