package ex_01_Java_Basics;

public class Lab011_Common_Math {
    public static void main(String[] args) {
        System.out.println("2+2");
        System.out.println(2+2);
        System.out.println(2*2);
        System.out.println(2/2);
        System.out.println(2-2);
        System.out.println(3/2); // // println ->Integer part -> No decimal
    }
}
