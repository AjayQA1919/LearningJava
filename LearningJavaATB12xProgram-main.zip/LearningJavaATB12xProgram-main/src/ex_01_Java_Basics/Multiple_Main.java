package ex_01_Java_Basics;

public class Multiple_Main {
    public static void main(String[] args) {

    }

    public static void main(int args) {

    }

    public static void main(String args) {

    }


}
