package ex_01_Java_Basics;

public class Lab001_HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hi, Pramod");

        // This is Pramod, This code will not executed

        /*
        * Author :  Pramod Dutta
        *
        *
        * */


    }
}


