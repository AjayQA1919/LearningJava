package ex_01_Java_Basics;

public class Lab009_Keywords_Identifiers {
    public static void main(String[] args) {
        System.out.println("Hi, Keyword!");

    }
}
