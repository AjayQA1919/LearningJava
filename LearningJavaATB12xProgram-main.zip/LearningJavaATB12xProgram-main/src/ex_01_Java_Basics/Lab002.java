package ex_01_Java_Basics;

public class Lab002 {

    public static void main(String[] args) {

        System.out.println("This is a Statement!");


    }


}
