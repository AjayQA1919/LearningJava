package ex_01_Java_Basics;

public class Lab010_Keywords_Identifier {
    public static void main(String[] args) {
        System.out.println("Hi");
        System.out.println("Bye");
    }
}
