package ex_03_Literals;

public class Lab035_Non_Primitive_Literal {

    public static void main(String[] args) {

        // Primitive Data Type - Defined by Java Guys
        // Max, Min, Size defined

        byte b = 10; // 1 Byte -> 8 Bits
        int age = 65; // 4 Byte -> 32 Bits

        // Non Primitive ( Defined by users) , Reference Data Types
        // No Size, max, min
        // Byte - 8 , Bits - 64

        String name = "Pramod"; // String is bunch of char.
        int[] arrays_of_items = new int[10];



    }
}
