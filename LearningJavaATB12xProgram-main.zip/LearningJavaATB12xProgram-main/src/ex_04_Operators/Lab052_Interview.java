package ex_04_Operators;

public class Lab052_Interview {
    public static void main(String[] args) {
        int a = 10;
        boolean b = (10 == 11); // == -> Comparison 2 values
        System.out.println(a);
        System.out.println(b);
    }
}
