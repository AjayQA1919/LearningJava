package ex_04_Operators;

public class Lab042_Interview_Concat_Plus {
    public static void main(String[] args) {
        // concatenation
        String s1 = "Pramod";
        String s2 = "Dutta";
        System.out.println(s1 + s2); // Joins

        int a = 10;
        int b = 20;
        System.out.println(a + b); // Math

        // + -> behave differently with the data type.
        // + -> operator overloading


    }
}
