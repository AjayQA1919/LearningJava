package ex_04_Operators;

public class Lab055_Interview {
    public static void main(String[] args) {
        System.out.println('A' == 65);
    }
}
