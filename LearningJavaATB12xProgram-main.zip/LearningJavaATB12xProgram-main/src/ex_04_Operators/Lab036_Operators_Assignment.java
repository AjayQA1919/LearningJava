package ex_04_Operators;

public class Lab036_Operators_Assignment {
    public static void main(String[] args) {

        int age = 90;
        // Assignment operator
        // int -> data type
        // age -> identifier
        // = -> Assignment operator
        // 90 -> Literal

        // RHV to the LH


    }
}
