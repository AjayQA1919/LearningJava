package ex_02_Java_Basics_Part2;

public class Lab022_Numerics_Data_Types {
    public static void main(String[] args) {

        //byte b = 128; // -128 to 127
        byte b = 10;
        int i = 10;
        short s = 10;
        char c  = 'A';
        long l = 9876543210l;
        long l1 = 9876543210L;

        float f = 3.14f;
        float f1 = 3.14F;

        double d = 3.123454345343;









    }
}
