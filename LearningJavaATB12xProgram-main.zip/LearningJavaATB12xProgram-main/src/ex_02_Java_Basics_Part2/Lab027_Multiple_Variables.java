package ex_02_Java_Basics_Part2;

public class Lab027_Multiple_Variables {
    public static void main(String[] args) {
        int a = 10, b = 23, c = 90;
        int _ = 10;
        //System.out.println(_);
    }
}
