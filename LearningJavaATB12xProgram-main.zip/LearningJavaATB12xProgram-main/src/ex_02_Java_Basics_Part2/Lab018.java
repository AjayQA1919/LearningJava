package ex_02_Java_Basics_Part2;

public class Lab018 {
    public static void main(String[] args) {
        int _ = 65;
        int $ = 65;
        int year = 2025;
        int this_is_a_vari_long_name_in_the_class_hello_$_akakak = 89;


    }
}
