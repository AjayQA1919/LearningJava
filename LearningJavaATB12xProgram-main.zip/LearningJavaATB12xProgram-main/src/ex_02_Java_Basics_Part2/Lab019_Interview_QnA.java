package ex_02_Java_Basics_Part2;

public class Lab019_Interview_QnA {
    public static void main(String[] args) {
        int _2 = 123;
        System.out.println(_2);
        int _1 = 123;
        int _0 = 123;
    }
}
