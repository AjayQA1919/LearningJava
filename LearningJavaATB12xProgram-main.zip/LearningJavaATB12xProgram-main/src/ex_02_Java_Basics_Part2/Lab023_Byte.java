package ex_02_Java_Basics_Part2;

public class Lab023_Byte {
    public static void main(String[] args) {

        byte age = 10;
        System.out.println(age);


    }
    public static void main(int args) {

        byte age = 11;
        System.out.println(age);

    }



}
